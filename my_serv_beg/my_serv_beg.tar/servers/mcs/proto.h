/* Function prototypes. */

/* main.c */
_PROTOTYPE( int  main, (int argc, char **argv)				);
